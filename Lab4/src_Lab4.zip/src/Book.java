
public class Book extends Item {

private String author;
private int ISBN;

// --- Constructor

public Book(String name, String author, int ISBN) {
super(name);
this.author = author;
this.ISBN = ISBN;
}

// --- Implementing the getListing method which returns title, author and ISBN#

@Override
public String getListing() {
return "Book Name - " + title + "\n" + "Author: " + author + "\n" + "ISBN# " + ISBN;
}

}
