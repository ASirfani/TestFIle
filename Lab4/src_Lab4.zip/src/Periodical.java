
public class Periodical extends Item {

private int issueNum;

public Periodical(String name, int issueNum) {
super(name);
this.issueNum = issueNum;
}

// ---- Implementing getListing method

@Override
public String getListing() {

// -- Return Periodical Title and Issue# as specified in statement

return "Periodical Title: " + title + "\n" + "Issue# " + issueNum;
}

}
